const correctToken = "2517";

function verifyToken() {
  const input = document.getElementById("tokenInput").value;
  const content = document.getElementById("securedContent");
  if (input === correctToken) {
    content.classList.remove("hidden");
    alert("Добро пожаловать, Ильяс.");
  } else {
    alert("Неверный токен.");
  }
}
